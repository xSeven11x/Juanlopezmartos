/* ═══════════════════════════════════════════════
   CONSTANTES Y UTILIDADES
═══════════════════════════════════════════════ */
const FUEL_OPTIONS = [
  { value:"gasolina95", label:"Gasolina 95", fields:["Precio Gasolina 95 E5","Precio Gasolina 95 E10","Precio Gasolina 95 E25","Precio Gasolina 95 Premium"] },
  { value:"gasolina98", label:"Gasolina 98", fields:["Precio Gasolina 98 E5","Precio Gasolina 98 E10","Precio Gasolina 98 E5 Premium"] },
  { value:"diesel",     label:"Diésel",      fields:["Precio Gasoleo A","Precio Gasoleo B","Precio Gasoleo Premium","Precio Diésel Renovable"] }
];

const FAV_KEY     = "ahorragas_favs";
const CACHE_KEY   = "ahorragas_data";
const HISTORY_KEY = "ahorragas_history";
const CACHE_TTL   = 60 * 60 * 1000; // 1 hora
const FETCH_TIMEOUT = 12000;
const PAGE_SIZE   = 30;

/* ── Storage helpers con try/catch completo ── */
function safeGet(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key) || "null") ?? fallback; }
  catch { return fallback; }
}
function safeSet(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); }
  catch (e) { console.warn("localStorage no disponible:", e); }
}

function loadFavs()    { return safeGet(FAV_KEY, []); }
function saveFavs(ids) { safeSet(FAV_KEY, ids); }

/* ── Historial de precios ── */
function loadHistory()   { return safeGet(HISTORY_KEY, {}); }
function saveHistory(h)  { safeSet(HISTORY_KEY, h); }

function recordPrices(stations, fuel) {
  const h   = loadHistory();
  const key = `${fuel}_${new Date().toISOString().slice(0,10)}`;
  if (!h[key]) h[key] = {};
  stations.forEach(s => { h[key][s.id] = s.price; });
  saveHistory(h);
}

function getPrevPrice(id, fuel) {
  const h = loadHistory();
  const today = new Date().toISOString().slice(0,10);
  const keys = Object.keys(h)
    .filter(k => k.startsWith(fuel + "_") && k < `${fuel}_${today}`)
    .sort().reverse();
  for (const k of keys) {
    if (h[k][id] !== undefined) return h[k][id];
  }
  return null;
}

/* ── Caché de historial por fuel ── */
function buildPriceHistoryMap(fuel, stations) {
  const map = {};
  stations.forEach(s => {
    map[s.id] = getPrevPrice(s.id, fuel);
  });
  return map;
}

/* ════════════════════════════════════════════════
   Tipos de error
════════════════════════════════════════════════ */
const ERROR_TYPES = {
  OFFLINE:  "offline",
  TIMEOUT:  "timeout",
  SERVER:   "server",
  UNKNOWN:  "unknown",
};

const ERROR_INFO = {
  [ERROR_TYPES.OFFLINE]: {
    icon: "📡",
    title: "Sin conexión a internet",
    msg: "Comprueba tu WiFi o datos móviles e inténtalo de nuevo."
  },
  [ERROR_TYPES.TIMEOUT]: {
    icon: "⏱️",
    title: "La API tardó demasiado",
    msg: "El servidor del Ministerio no respondió a tiempo. Puede estar saturado, inténtalo en unos segundos."
  },
  [ERROR_TYPES.SERVER]: {
    icon: "🔧",
    title: "Error del servidor",
    msg: "La API oficial devolvió un error. Puede ser una caída temporal del Ministerio de Industria."
  },
  [ERROR_TYPES.UNKNOWN]: {
    icon: "❓",
    title: "Error inesperado",
    msg: "Algo salió mal. Inténtalo de nuevo o recarga la página."
  },
};

function classifyError(err) {
  if (!navigator.onLine)           return ERROR_TYPES.OFFLINE;
  if (err.name === "AbortError")   return ERROR_TYPES.TIMEOUT;
  if (err.name === "ServerError")  return ERROR_TYPES.SERVER;
  return ERROR_TYPES.UNKNOWN;
}

async function fetchWithCache(forceFresh = false) {
  if (!forceFresh) {
    const cached = safeGet(CACHE_KEY, null);
    if (cached && Date.now() - cached.ts < CACHE_TTL) {
      return { data: cached.data, fromCache: true };
    }
  }

  if (!navigator.onLine) {
    const cached = safeGet(CACHE_KEY, null);
    if (cached) return { data: cached.data, fromCache: true, stale: true };
    const err = new Error("Sin conexión");
    err.errorType = ERROR_TYPES.OFFLINE;
    throw err;
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT);

  try {
    const r = await fetch(
      "https://sedeaplicaciones.minetur.gob.es/ServiciosRESTCarburantes/PreciosCarburantes/EstacionesTerrestres/FiltroProvincia/41",
      { signal: controller.signal }
    );
    clearTimeout(timer);

    if (!r.ok) {
      const err = new Error(`HTTP ${r.status}`);
      err.name = "ServerError";
      err.errorType = ERROR_TYPES.SERVER;
      throw err;
    }

    const data = await r.json();
    safeSet(CACHE_KEY, { ts: Date.now(), data });
    return { data, fromCache: false };

  } catch (err) {
    clearTimeout(timer);
    if (!err.errorType) err.errorType = classifyError(err);
    throw err;
  }
}

/* ── Utilidades ── */
function parsePrice(str) { return parseFloat(String(str).replace(",",".")); }

function normalizeFuel(raw, fields) {
  let price = null;
  for (const f of fields) {
    if (raw[f] && String(raw[f]).trim() !== "") {
      const p = parsePrice(raw[f]);
      if (!isNaN(p) && p > 0) { price = p; break; }
    }
  }
  if (price === null) return null;

  const lat = parseFloat(String(raw["Latitud"]).replace(",","."));
  const lon = parseFloat(String(raw["Longitud (WGS84)"]).replace(",","."));
  if (isNaN(lat) || isNaN(lon)) return null;

  return {
    id:        raw["IDEESS"],
    name:      raw["Rótulo"],
    address:   raw["Dirección"],
    price,
    latitude:  lat,
    longitude: lon,
  };
}

function distanceKm(lat1,lon1,lat2,lon2) {
  const R=6371, dLat=(lat2-lat1)*Math.PI/180, dLon=(lon2-lon1)*Math.PI/180;
  const a=Math.sin(dLat/2)**2+Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
  return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}

async function shareStation(s) {
  const text = `⛽ ${s.name}\n📍 ${s.address}\n💰 ${s.price.toFixed(3)} €/L\n\nhttps://www.google.com/maps?q=${s.latitude},${s.longitude}`;
  if (navigator.share) {
    try { await navigator.share({ title: "AhorraGas", text }); } catch {}
  } else {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      return false;
    }
  }
  return false;
}

/* ════════════════════════════════════════════════
   MapModule
════════════════════════════════════════════════ */
const MapModule = (() => {
  let map = null;
  let markerCluster = null;
  let userMarkerRef = null;
  let accuracyCircleRef = null;
  let mapInitialized = false;
  let pendingStationUpdate = null;

  let markersById     = {};
  let stationDataById = {};
  let currentFavIds   = [];
  let currentUserLoc  = null;

  let onReadyCallbacks = [];
  /* ============================================================
     ICONO DINÁMICO SEGÚN PRECIO
  ============================================================ */
function getPriceIcon(price) {
  const cheap = 1.45;
  const medium = 1.60;

  let bg, stroke;
  if (price > medium) {
    bg = "#fee2e2"; stroke = "#dc2626";   // rojo
  } else if (price > cheap) {
    bg = "#fef3c7"; stroke = "#d97706";   // amarillo
  } else {
    bg = "#dcfce7"; stroke = "#16a34a";   // verde
  }

  const minSize = 26;
  const maxSize = 34;
  const normalized = Math.max(1.30, Math.min(price, 1.80));
  const size = maxSize - ((normalized - 1.30) * (maxSize - minSize) / 0.50);

  const html =
    `<div style="
      width:${size}px;
      height:${size}px;
      border-radius:12px;
      background:${bg};
      box-shadow:0 2px 6px rgba(0,0,0,0.25);
      display:flex;
      align-items:center;
      justify-content:center;
      animation:pop 0.35s ease-out;
    ">
      <svg viewBox='0 0 24 24' width='${size * 0.7}' height='${size * 0.7}'>
        <rect x='5' y='5' width='9' height='13' rx='2'
          fill='white' stroke='${stroke}' stroke-width='1.6'/>
        <rect x='7' y='7' width='5' height='4' rx='1.2'
          fill='${stroke}'/>
        <rect x='7.3' y='12.2' width='4.4' height='4.2' rx='1.2'
          fill='#e5e7eb'/>
        <path d='M14 7.5 L17 5.5 C18 5 19 5.4 19.3 6.2 L20.4 9
                 C20.8 10 20.5 11.1 19.7 11.7
                 C18.9 12.3 17.8 12.1 17.2 11.3
                 L16.2 10'
          fill='none' stroke='${stroke}' stroke-width='1.4'
          stroke-linecap='round' stroke-linejoin='round'/>
        <circle cx='18.4' cy='9.2' r='0.9' fill='${stroke}'/>
      </svg>
    </div>`;

  return L.divIcon({
    html,
    className: "",
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2]
  });
}

function getClusterColor(avgPrice) {
  const cheap = 1.45;
  const medium = 1.60;

  if (avgPrice > medium) return "red";
  if (avgPrice > cheap) return "yellow";
  return "green";
}

/* ============================================================
   POPUP HTML
============================================================ */

function buildPopupHtml(s, isFav) {
  /* Sanitiza todos los datos que vienen de la API externa
     antes de interpolarlos en el HTML del popup           */
  const name    = Sanitize.e(s.name);
  const address = Sanitize.e(s.address);
  const price   = Sanitize.e(s.price.toFixed(3));
  const id      = Sanitize.e(s.id);
  const lat     = parseFloat(s.latitude).toFixed(6);   // número → no necesita escape
  const lon     = parseFloat(s.longitude).toFixed(6);  // número → no necesita escape

  const origin = currentUserLoc
    ? `${parseFloat(currentUserLoc.lat).toFixed(6)},${parseFloat(currentUserLoc.lon).toFixed(6)}`
    : '';

  return `
    <div style="font-family: Orbitron, sans-serif;">
      <b style="font-size:13px;">${name}</b><br>
      <span style="font-size:11px;color:#888;">${address}</span><br>
      <b style="font-size:14px;display:block;margin-top:6px;">${price} €</b>

      <div style="margin-top:12px;display:flex;flex-direction:column;gap:8px;">
        <a href="https://www.google.com/maps?q=${lat},${lon}" target="_blank" rel="noopener noreferrer"
          style="display:block;text-align:center;padding:10px 12px;background:#4ea1ff;color:white;border-radius:10px;font-weight:700;text-decoration:none;font-size:12px;">
          🧭 Ver ubicación
        </a>

        ${origin ? `
        <a href="https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${lat},${lon}&travelmode=driving"
          target="_blank" rel="noopener noreferrer"
          style="display:block;text-align:center;padding:10px 12px;background:#1e293b;color:#4ea1ff;border:1px solid #4ea1ff;border-radius:10px;font-weight:700;text-decoration:none;font-size:12px;">
          🚗 Ir en ruta
        </a>` : ''}
      </div>

      <div style="margin-top:12px;">
        <button onclick="window._toggleFavPopup('${id}')"
          style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid rgba(245,158,11,0.4);
          background:${isFav ? 'rgba(245,158,11,0.15)' : 'transparent'};
          color:${isFav ? '#f59e0b' : '#888'};cursor:pointer;font-weight:600;font-size:12px;font-family:Orbitron,sans-serif;">
          ${isFav ? '★ Guardada' : '☆ Guardar'}
        </button>
      </div>
    </div>
  `;
}

/* ============================================================
   API PÚBLICA DEL MAPA
============================================================ */
return {
  isReady: () => mapInitialized,

  onReady(cb) {
    if (mapInitialized) cb();
    else onReadyCallbacks.push(cb);
  },

  init() {
    if (map) return;

    map = L.map("map").setView([37.3891, -5.9845], 11);

    L.tileLayer(
      "https://cartodb-basemaps-{s}.global.ssl.fastly.net/light_all/{z}/{x}/{y}.png",
      { attribution: "&copy; OpenStreetMap &copy; CARTO" }
    ).addTo(map);

    mapInitialized = true;

    onReadyCallbacks.forEach(cb => cb());
    onReadyCallbacks = [];

    if (pendingStationUpdate) {
      const { stations, favIds, userLoc } = pendingStationUpdate;
      pendingStationUpdate = null;
      this.updateStationMarkers(stations, favIds, userLoc);
    }
  },

  invalidate() {
    if (map) setTimeout(() => map.invalidateSize(), 360);
  },

  updateUserMarker(userLoc, accuracy) {
    if (!map || !userLoc) return;

    currentUserLoc = userLoc;

    if (userMarkerRef) map.removeLayer(userMarkerRef);

    const icon = L.divIcon({
      html: `<div style="width:16px;height:16px;background:#4ea1ff;border:3px solid #fff;border-radius:50%;box-shadow:0 0 0 4px rgba(78,161,255,0.4)"></div>`,
      className: "",
      iconAnchor: [8, 8],
    });

    userMarkerRef = L.marker([userLoc.lat, userLoc.lon], { icon, zIndexOffset: 1000 }).addTo(map);

    if (accuracyCircleRef) map.removeLayer(accuracyCircleRef);

    if (accuracy) {
      accuracyCircleRef = L.circle([userLoc.lat, userLoc.lon], {
        radius: accuracy,
        color: "#4ea1ff",
        fillColor: "#4ea1ff",
        fillOpacity: 0.15,
        weight: 1,
      }).addTo(map);
    }
  },

  updateStationMarkers(stations, favIds, userLoc) {
    if (!map) {
      pendingStationUpdate = { stations, favIds, userLoc };
      return;
    }

    currentFavIds  = favIds;
    currentUserLoc = userLoc;

    if (markerCluster) map.removeLayer(markerCluster);

    markersById     = {};
    stationDataById = {};

    markerCluster = L.markerClusterGroup({
      chunkedLoading: true,
      maxClusterRadius: 60,
      spiderfyOnMaxZoom: true,

      // 🔥 CLUSTER PERSONALIZADO
      iconCreateFunction: function (cluster) {
        const markers = cluster.getAllChildMarkers();

        let sum = 0;
        markers.forEach(m => {
          const id = Object.keys(markersById).find(key => markersById[key] === m);
          if (id && stationDataById[id]) {
            sum += stationDataById[id].price;
          }
        });

        const avg = sum / markers.length;
        const color = getClusterColor(avg);

        const size = Math.min(40 + markers.length * 1.5, 70);
        return L.divIcon({
          html: `
            <div style="
              width:${size}px;
              height:${size}px;
              background:${color};
              border-radius:50%;
              border:3px solid white;
              display:flex;
              align-items:center;
              justify-content:center;
              color:white;
              font-size:${size * 0.35}px;
              font-weight:900;
              box-shadow:0 0 12px rgba(0,0,0,0.35);
            ">
              ${markers.length}
            </div>
          `,
          className: "",
          iconSize: [size, size],
          iconAnchor: [size / 2, size / 2]
        });
      }
    });

    stations.forEach((s) => {
      stationDataById[s.id] = s;

      const isFav = favIds.includes(s.id);
      const icon  = getPriceIcon(s.price);

      const m = L.marker([s.latitude, s.longitude], { icon });
      m.bindPopup(buildPopupHtml(s, isFav), { maxWidth: 260 });

      markersById[s.id] = m;
      markerCluster.addLayer(m);
    });

    map.addLayer(markerCluster);
  },

  updateFavMarkers(newFavIds) {
    if (!map) return;

    const oldSet = new Set(currentFavIds);
    const newSet = new Set(newFavIds);

    const changed = [...new Set([...oldSet, ...newSet])]
      .filter(id => oldSet.has(id) !== newSet.has(id));

    changed.forEach(id => {
      const m = markersById[id];
      const s = stationDataById[id];
      if (!m || !s) return;
      m.setPopupContent(buildPopupHtml(s, newSet.has(id)));
    });

    currentFavIds = newFavIds;
  },

  flyToUser(userLoc) {
    if (!map) return;
    if (!userLoc) { alert("Aún no tengo tu ubicación."); return; }
    map.flyTo([userLoc.lat, userLoc.lon], 16, { animate: true, duration: 1.2 });
  },

  flyToStation(station) {
    if (!map) return;
    map.flyTo([station.latitude, station.longitude], 16, { animate: true, duration: 1.2 });
    const marker = markersById[station.id];
    if (marker) setTimeout(() => marker.openPopup(), 700);
  },
};
})();
/* ═══════════════════════════════════════════════
   COMPONENTES
═══════════════════════════════════════════════ */

function SkeletonCard() {
  return (
    <div className="skeleton-card">
      <div className="skeleton-info">
        <div className="skeleton-block" style={{height:"14px", width:"60%"}}></div>
        <div className="skeleton-block" style={{height:"11px", width:"80%"}}></div>
        <div style={{display:"flex",gap:"6px",marginTop:"4px"}}>
          <div className="skeleton-block" style={{height:"20px", width:"80px", borderRadius:"999px"}}></div>
          <div className="skeleton-block" style={{height:"20px", width:"60px", borderRadius:"999px"}}></div>
        </div>
      </div>
      <div className="skeleton-right">
        <div className="skeleton-block" style={{height:"28px", width:"70px"}}></div>
        <div className="skeleton-block" style={{height:"11px", width:"40px"}}></div>
      </div>
    </div>
  );
}

function ErrorBanner({ errorType, onRetry, retrying }) {
  const info = ERROR_INFO[errorType] || ERROR_INFO["unknown"];
  return (
    <div className="error-banner">
      <div className="error-icon">{info.icon}</div>
      <div className="error-title">{info.title}</div>
      <div className="error-msg">{info.msg}</div>
      <div className="error-actions">
        <button
          className="retry-btn"
          onClick={onRetry}
          disabled={retrying}
          style={retrying ? {opacity:0.5,cursor:"not-allowed"} : {}}
        >
          {retrying ? "⟳ Reintentando..." : "⟳ Reintentar"}
        </button>
        <button
          className="retry-btn"
          style={{borderColor:"rgba(78,161,255,0.35)", color:"#4ea1ff", background:"rgba(78,161,255,0.08)"}}
          onClick={() => window.location.reload()}
        >
          ↺ Recargar página
        </button>
      </div>
    </div>
  );
}

/* ── StationCard con feedback de compartir ── */
/* CAMBIO: Se añade onCardClick como prop */
const StationCard = React.memo(function StationCard({ s, fuel, favIds, toggleFav, userLoc, prevPrice, onCardClick }) {
  const isFav   = favIds.includes(s.id);
  const trend   = prevPrice === null ? null : s.price > prevPrice ? "up" : s.price < prevPrice ? "down" : "same";
  const diff    = prevPrice !== null ? Math.abs(s.price - prevPrice).toFixed(3) : null;
  const [copied, setCopied] = React.useState(false);

  const distLabel = s.distance != null
    ? `📍 ${s.distance < 1 ? (s.distance*1000).toFixed(0)+"m" : s.distance.toFixed(1)+"km"}`
    : userLoc
      ? `📍 ${distanceKm(userLoc.lat, userLoc.lon, s.latitude, s.longitude).toFixed(1)}km`
      : null;

  const handleShare = async () => {
    const wasCopied = await shareStation(s);
    if (wasCopied) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  /* CAMBIO: onClick en el div principal que ignora clics en botones y enlaces */
  const handleCardClick = (e) => {
    if (e.target.closest("button, a")) return;
    onCardClick(s);
  };

  return (
    /* CAMBIO: onClick y cursor:pointer añadidos al div raíz */
    <div
      id={`station-${s.id}`}
      className={`station-card${isFav ? " is-fav" : ""}`}
      onClick={handleCardClick}
      style={{ cursor: "pointer" }}
    >
      <div className="station-info">
        <div className="station-name">{s.name}</div>
        <div className="station-address">{s.address}</div>
        <div className="station-meta">
          <span className="station-tag">
            {fuel === "gasolina95" && "Gasolina 95"}
            {fuel === "gasolina98" && "Gasolina 98"}
            {fuel === "diesel"     && "Diésel"}
          </span>
          {distLabel && <span className="dist-tag">{distLabel}</span>}
          {isFav && <span className="fav-tag">★ Favorita</span>}
          {trend === "up"   && <span className="price-trend up">▲ +{diff}</span>}
          {trend === "down" && <span className="price-trend down">▼ -{diff}</span>}
        </div>
      </div>
      <div className="station-right">
        <div style={{display:"flex", gap:"6px"}}>
          <button
            className={`share-btn${copied ? " copied" : ""}`}
            title={copied ? "¡Copiado!" : "Compartir"}
            onClick={handleShare}
          >
            {copied ? "✓" : "📤"}
          </button>
          <button
            className={`fav-btn${isFav ? " active" : ""}`}
            title={isFav ? "Quitar de favoritas" : "Añadir a favoritas"}
            onClick={() => toggleFav(s.id)}
          >
            {isFav ? "★" : "☆"}
          </button>
        </div>
        <div className="station-price">
          <div className="price-value">{s.price.toFixed(3)}</div>
          <div className="price-unit">€/L</div>
          <div style={{display:"flex", flexDirection:"column", gap:"4px"}}>
            <a className="maps-btn" href={`https://www.google.com/maps?q=${s.latitude},${s.longitude}`} target="_blank" rel="noreferrer">
              Ver ubicación
            </a>
            {userLoc && (
              <a className="maps-btn"
                href={`https://www.google.com/maps/dir/?api=1&origin=${userLoc.lat},${userLoc.lon}&destination=${s.latitude},${s.longitude}&travelmode=driving`}
                target="_blank" rel="noreferrer"
                style={{color:"#4ea1ff",fontWeight:"700"}}
              >
                🚗 Ir en ruta
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
/* CAMBIO: onCardClick añadido a la comparación del memo */
}, (prev, next) => {
  return prev.s.id      === next.s.id &&
    prev.s.price        === next.s.price &&
    prev.prevPrice      === next.prevPrice &&
    prev.favIds.includes(prev.s.id) === next.favIds.includes(next.s.id) &&
    prev.fuel           === next.fuel &&
    prev.userLoc?.lat   === next.userLoc?.lat &&
    prev.onCardClick    === next.onCardClick;
});

/* ═══════════════════════════════════════════════
   APP PRINCIPAL — INICIO
═══════════════════════════════════════════════ */
function App() {
  const [fuel, setFuel]               = React.useState("gasolina95");
  const [stations, setStations]       = React.useState([]);
  const [userLoc, setUserLoc]         = React.useState(null);
  const [nearbyOnly, setNearbyOnly]   = React.useState(false);
  const [viewMode, setViewMode]       = React.useState("all");
  const [sortMode, setSortMode]       = React.useState("precio");
  const [search, setSearch]           = React.useState("");
  const [suggestions, setSuggestions] = React.useState([]);
  const [fuelCache, setFuelCache]     = React.useState(null);
  const [loading, setLoading]         = React.useState(true);
  const [fromCache, setFromCache]     = React.useState(false);
  const [staleCache, setStaleCache]   = React.useState(false);
  const [lightMode, setLightMode]     = React.useState(false);
  const [mapExpanded, setMapExpanded] = React.useState(true);
  const [favIds, setFavIds]           = React.useState(loadFavs);
  const [showFavs, setShowFavs]       = React.useState(false);
  const [visibleCount, setVisibleCount] = React.useState(PAGE_SIZE);
  const [showNotifBanner, setShowNotifBanner] = React.useState(false);
  const [fetchError, setFetchError]   = React.useState(null);
  const [retrying, setRetrying]       = React.useState(false);
  const [gpsActive, setGpsActive]     = React.useState(false);

  const searchRef  = React.useRef(null);
  const mapRef     = React.useRef(null);
  const prevFavIdsRef      = React.useRef(favIds);
  const prevStationsRef    = React.useRef(null);
  const mapReadyRef        = React.useRef(false);
  /* Sync userLoc global para popups */
  React.useEffect(() => { window._userLoc = userLoc; }, [userLoc]);

  /* Botón favorito en popup del mapa */
  React.useEffect(() => {
    window._toggleFavPopup = (id) => {
      setFavIds(prev => {
        const next = prev.includes(id) ? prev.filter(f=>f!==id) : [...prev, id];
        saveFavs(next);
        return next;
      });
    };
  }, []);

  /* Persistir favs */
  React.useEffect(() => { saveFavs(favIds); }, [favIds]);

  const toggleFav = React.useCallback((id) => {
    setFavIds(prev => prev.includes(id) ? prev.filter(f=>f!==id) : [...prev, id]);
  }, []);

  /* CAMBIO: handleCardClick con useCallback para referencia estable y no romper React.memo */
  const handleCardClick = React.useCallback((station) => {
    MapModule.flyToStation(station);
    mapRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, []);

  /* Tema */
  React.useEffect(() => {
    document.documentElement.classList.toggle("light", lightMode);
  }, [lightMode]);

  /* GPS */
  React.useEffect(() => {
    if (!navigator.geolocation) return;
    let lastLat = null, lastLon = null;
    const watchId = navigator.geolocation.watchPosition(pos => {
      const { latitude, longitude, accuracy } = pos.coords;
      if (accuracy > 200) return;
      if (lastLat !== null) {
        const d = distanceKm(lastLat, lastLon, latitude, longitude);
        if (d < 0.05) return;
      }
      lastLat = latitude; lastLon = longitude;
      const loc = { lat: latitude, lon: longitude };
      setUserLoc(loc);
      setGpsActive(true);
      MapModule.updateUserMarker(loc, accuracy);
    },
    err => { console.log("Error GPS:", err); setGpsActive(false); },
    { enableHighAccuracy: true, timeout: 20000, maximumAge: 30000 });
    return () => navigator.geolocation.clearWatch(watchId);
  }, []);

  /* Banner notificaciones */
  React.useEffect(() => {
    if ("Notification" in window && Notification.permission === "default") {
      setTimeout(() => setShowNotifBanner(true), 3000);
    }
  }, []);

  /* ── Carga de datos ── */
const loadData = React.useCallback(async (forceFresh = false) => {
    window._loadingBar?.start();  // ← AÑADE ESTA LÍNEA
    setLoading(true);
    setFetchError(null);
    try {
      const { data, fromCache: fc, stale } = await fetchWithCache(forceFresh);
      setFuelCache(data);
      setFromCache(fc);
      setStaleCache(!!stale);
      setFetchError(null);
    } catch (err) {
      setFetchError(err.errorType || ERROR_TYPES.UNKNOWN);
    } finally {
      setLoading(false);
      setRetrying(false);
      window._loadingBar?.finish();  // ← AÑADE ESTA LÍNEA
    }
  }, []);

  const handleRetry = React.useCallback(async () => {
    setRetrying(true);
    await loadData(true);
  }, [loadData]);

  React.useEffect(() => { loadData(); }, [loadData]);

  /* ── Lazy init del mapa ── */
  React.useEffect(() => {
    if (!mapRef.current) return;
    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        MapModule.init();
        mapReadyRef.current = true;
        observer.disconnect();
      }
    }, { threshold: 0.1 });
    observer.observe(mapRef.current);
    return () => observer.disconnect();
  }, []);

  /* ── Sugerencias ── */
  React.useEffect(() => {
    if (!fuelCache || !search.trim()) { setSuggestions([]); return; }
    const fields = FUEL_OPTIONS.find(f=>f.value===fuel).fields;
    const q = search.toLowerCase();
    const list = fuelCache.ListaEESSPrecio
      .map(s=>normalizeFuel(s,fields))
      .filter(Boolean)
      .filter(s=>s.name.toLowerCase().includes(q)||s.address.toLowerCase().includes(q))
      .slice(0,6);
    setSuggestions(list);
  }, [search, fuelCache, fuel]);

  /* ── Lista principal ── */
  React.useEffect(() => {
    if (!fuelCache) return;
    const fields = FUEL_OPTIONS.find(f=>f.value===fuel).fields;
    let list = fuelCache.ListaEESSPrecio.map(s=>normalizeFuel(s,fields)).filter(Boolean);

    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(s=>s.name.toLowerCase().includes(q)||s.address.toLowerCase().includes(q));
    }

    if (userLoc) {
      list = list.map(s => ({
        ...s,
        distance: distanceKm(userLoc.lat, userLoc.lon, s.latitude, s.longitude)
      }));
    }

    if (nearbyOnly && userLoc) {
      list = list.filter(s => s.distance <= 10);
    }

    if (sortMode === "distancia" && userLoc) {
      list = list.sort((a,b) => a.distance - b.distance);
    } else {
      list = list.sort((a,b) => a.price - b.price);
    }

    if (viewMode === "top5") list = list.slice(0,5);

    setStations(list);
    setVisibleCount(PAGE_SIZE);
  }, [fuel, nearbyOnly, viewMode, sortMode, search, fuelCache, userLoc]);

  /* ── Guardar historial ── */
  React.useEffect(() => {
    if (!fuelCache || stations.length === 0) return;
    recordPrices(stations, fuel);
  }, [fuel, fuelCache]);

  /* ── Historial memoizado ── */
  const priceHistoryMap = React.useMemo(() => {
    return buildPriceHistoryMap(fuel, stations);
  }, [fuel, stations]);

  /* ════════════════════════════════════════════
     Actualizar mapa
  ════════════════════════════════════════════ */

  React.useEffect(() => {
    const mapData = showFavs ? stations.filter(s=>favIds.includes(s.id)) : stations;
    prevStationsRef.current = mapData;

    if (!MapModule.isReady()) {
      MapModule.onReady(() => {
        MapModule.updateStationMarkers(mapData, favIds, userLoc);
        prevFavIdsRef.current = favIds;
      });
      return;
    }
    MapModule.updateStationMarkers(mapData, favIds, userLoc);
    prevFavIdsRef.current = favIds;
  }, [stations, showFavs, userLoc]);

  React.useEffect(() => {
    if (!MapModule.isReady()) return;
    if (prevFavIdsRef.current === favIds) return;
    MapModule.updateFavMarkers(favIds);
    prevFavIdsRef.current = favIds;
  }, [favIds]);

  React.useEffect(() => { MapModule.invalidate(); }, [mapExpanded]);

  /* Cerrar sugerencias al click fuera */
  React.useEffect(() => {
    const fn = (e) => {
      if (searchRef.current && !searchRef.current.contains(e.target)) setSuggestions([]);
    };
    document.addEventListener("mousedown", fn);
    document.addEventListener("touchstart", fn, { passive: true });
    return () => {
      document.removeEventListener("mousedown", fn);
      document.removeEventListener("touchstart", fn);
    };
  }, []);

  const handleSuggestionClick = (s) => {
    setSearch(s.name);
    setSuggestions([]);
    if (MapModule.isReady()) MapModule.flyToStation(s);
  };

  const requestNotifications = async () => {
    const permission = await Notification.requestPermission();
    setShowNotifBanner(false);
    if (permission === "granted") {
      new Notification("AhorraGas 🔔", {
        body: "Te avisaremos cuando tus favoritas bajen de precio.",
        icon: "img/logo.png"
      });
    }
  };

  const displayedStations = showFavs ? stations.filter(s=>favIds.includes(s.id)) : stations;
  const visibleStations   = viewMode === "top5" ? displayedStations : displayedStations.slice(0, visibleCount);
  const hasMore           = visibleCount < displayedStations.length && viewMode !== "top5";
  const remaining         = displayedStations.length - visibleCount;
  const favCount          = favIds.length;

  return (
    <div>
      {/* ── HEADER ── */}
      <header className="header">
        <div className="header-inner">
          <div className="header-left">
            <img src="img/logo.png" className="header-logo" alt="logo" />
            <div className="header-titles">
              <h1>AhorraGas</h1>
              <p>Datos oficiales en tiempo real</p>
            </div>
          </div>
          <button
            onClick={() => setLightMode(v => !v)}
            title={lightMode ? "Cambiar a modo oscuro" : "Cambiar a modo claro"}
            style={{
              background: "rgba(255,255,255,0.07)",
              border: "1px solid rgba(255,255,255,0.12)",
              borderRadius: "50%", width: "42px", height: "42px",
              cursor: "pointer", fontSize: "22px",
              display: "flex", alignItems: "center", justifyContent: "center",
              transition: "background 0.2s, transform 0.3s",
            }}
            onMouseEnter={e => e.currentTarget.style.background = "rgba(255,255,255,0.15)"}
            onMouseLeave={e => e.currentTarget.style.background = "rgba(255,255,255,0.07)"}
          >
            {lightMode ? "🌙" : "☀️"}
          </button>
        </div>
      </header>

      <div className="content">

        {/* ── BANNER NOTIFICACIONES ── */}
        {showNotifBanner && (
          <div className="notif-banner">
            <span>🔔 Activa notificaciones para que te avisemos cuando tus favoritas bajen de precio</span>
            <button onClick={requestNotifications}>Activar</button>
            <button className="notif-banner-close" onClick={()=>setShowNotifBanner(false)}>×</button>
          </div>
        )}

        {/* ── BADGE CACHÉ / OFFLINE ── */}
        {fromCache && !staleCache && (
          <div className="offline-badge">
            ⚡ Datos en caché · actualizados hace menos de 1h
          </div>
        )}
        {staleCache && (
          <div className="offline-badge" style={{color:"#ef4444", background:"rgba(239,68,68,0.1)", borderColor:"rgba(239,68,68,0.3)"}}>
            ⚠️ Sin conexión · mostrando datos guardados (pueden no ser actuales)
          </div>
        )}

        {/* ── BANNER DE ERROR ── */}
        {fetchError && (
          <ErrorBanner
            errorType={fetchError}
            onRetry={handleRetry}
            retrying={retrying}
          />
        )}

        {/* ── CONTROLES ── */}
        <div className="controls-wrapper">
          <div className="fuel-selector">
            {FUEL_OPTIONS.map(opt=>(
              <button key={opt.value} className={"fuel-btn"+(fuel===opt.value?" active":"")} onClick={()=>setFuel(opt.value)}>
                {opt.label}
              </button>
            ))}
          </div>
          <div className="view-selector">
            <button className={"toggle-btn"+(viewMode==="all"&&!showFavs?" active":"")} onClick={()=>{setViewMode("all");setShowFavs(false);}}>Ver todas</button>
            <button className={"toggle-btn"+(viewMode==="top5"&&!showFavs?" active":"")} onClick={()=>{setViewMode("top5");setShowFavs(false);}}>Top 5 más baratas</button>
            <button className={"toggle-btn fav-tab"+(showFavs?" active":"")} onClick={()=>setShowFavs(v=>!v)}>
              ★ Favoritas{favCount>0?` (${favCount})`:""}
            </button>
          </div>

          <div className="sort-selector">
            <button className={"toggle-btn"+(sortMode==="precio"?" active":"")} onClick={()=>setSortMode("precio")}>
              💰 Precio
            </button>
            <button
              className={"toggle-btn"+(sortMode==="distancia"?" active":"")}
              onClick={()=>{ if(userLoc) setSortMode("distancia"); }}
              disabled={!userLoc}
              title={!userLoc ? "Esperando tu ubicación..." : "Ordenar por distancia"}
            >
              📍 Distancia
            </button>
            {!gpsActive && (
              <span className="gps-hint">📡 Activando GPS...</span>
            )}
          </div>

          <button className={"toggle-btn"+(nearbyOnly?" active":"")} onClick={()=>setNearbyOnly(v=>!v)}>
            Solo gasolineras a menos de 10 km
          </button>
        </div>

        {/* ── BARRA DE BÚSQUEDA ── */}
        <div className="search-wrapper" ref={searchRef}>
          <div className="search-label">Buscar gasolinera</div>
          <div className="search-bar">
            <div className="search-icon-wrap">
              <svg className="search-icon" viewBox="0 0 24 24">
                <circle cx="11" cy="11" r="7"/>
                <line x1="16.5" y1="16.5" x2="22" y2="22"/>
              </svg>
            </div>
            <input
              className="search-input"
              type="text"
              placeholder="🔍 Nombre o dirección..."
              value={search}
              onChange={e=>setSearch(e.target.value)}
            />
            {search && (
              <button className="search-clear" onClick={()=>setSearch("")}>×</button>
            )}
          </div>
          {suggestions.length>0 && (
            <div className="suggestions-box">
              {suggestions.map(s=>(
                <div key={s.id} className="suggestion-item" onClick={()=>handleSuggestionClick(s)}>
                  <div className="suggestion-title">{s.name}</div>
                  <div className="suggestion-sub">{s.address}</div>
                  <div className="suggestion-price">{s.price.toFixed(3)} €/L</div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ── MAPA ── */}
        <div className="map-container" ref={mapRef}>
          <div className="map-topbar">
            <span className="map-badge">Mapa de gasolineras · Sevilla</span>
            <div className="map-controls">
              <button className="map-btn" onClick={()=>MapModule.flyToUser(userLoc)}>
                <span className={`loc-dot${!userLoc?" no-loc":""}`}></span>
                Mi ubicación
              </button>
              <button className="map-btn" onClick={()=>setMapExpanded(v=>!v)}>
                {mapExpanded?"▲ Minimizar":"▼ Expandir"}
              </button>
            </div>
          </div>
          <div id="map" className={mapExpanded?"expanded":"collapsed"}></div>
        </div>

        {/* ── LISTA ── */}
        <div className="section-header">
          <div className="section-title">
            {showFavs ? "★ Gasolineras favoritas" : "Gasolineras"}
          </div>
          <div className="section-badge">{displayedStations.length} resultados</div>
        </div>

        <div className="stations-grid">
          {loading ? (
            Array.from({length:6}).map((_,i) => <SkeletonCard key={i} />)
          ) : fetchError && stations.length === 0 ? null
          : showFavs && displayedStations.length === 0 ? (
            <div className="empty-favs">
              <div className="empty-favs-icon">☆</div>
              <p>Aún no tienes favoritas.<br/>Pulsa ☆ en cualquier gasolinera<br/>para guardarla aquí.</p>
            </div>
          ) : (
            visibleStations.map(s => (
              <StationCard
                key={s.id}
                s={s}
                fuel={fuel}
                favIds={favIds}
                toggleFav={toggleFav}
                userLoc={userLoc}
                prevPrice={priceHistoryMap[s.id] ?? null}
                onCardClick={handleCardClick}
              />
            ))
          )}
        </div>

        {/* ── CARGAR MÁS ── */}
        {!loading && hasMore && (
          <button className="load-more-btn" onClick={()=>setVisibleCount(v=>v+PAGE_SIZE)}>
            Cargar más ({remaining} restantes)
          </button>
        )}

      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);