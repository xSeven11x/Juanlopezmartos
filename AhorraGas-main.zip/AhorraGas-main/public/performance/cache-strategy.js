/* ============================================================
   cache-strategy.js — Estrategias de caché en cliente
============================================================ */

window.ClientCache = {
  set(key, value, ttl = 60000) { // 1 minuto por defecto
    const item = {
      value,
      expiry: Date.now() + ttl
    };
    localStorage.setItem(key, JSON.stringify(item));
  },

  get(key) {
    const item = JSON.parse(localStorage.getItem(key) || "null");
    if (!item) return null;

    if (Date.now() > item.expiry) {
      localStorage.removeItem(key);
      return null;
    }

    return item.value;
  }
};
