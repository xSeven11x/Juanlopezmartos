/* ============================================================
   lazyload.js — Carga diferida de componentes
============================================================ */

window.LazyLoad = {
  loadScript(src) {
    return new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = src;
      s.async = true;
      s.onload = resolve;
      s.onerror = reject;
      document.body.appendChild(s);
    });
  },

  loadWhenVisible(selector, callback) {
    const el = document.querySelector(selector);
    if (!el) return;

    const observer = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        callback();
        observer.disconnect();
      }
    });

    observer.observe(el);
  }
};
