/* ============================================================
   optimize-react.js — Optimizaciones para React
============================================================ */

window.ReactOptimize = {
  throttle(fn, delay = 200) {
    let last = 0;
    return (...args) => {
      const now = Date.now();
      if (now - last >= delay) {
        last = now;
        fn(...args);
      }
    };
  },

  debounce(fn, delay = 200) {
    let timer;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args), delay);
    };
  },

  memoize(fn) {
    const cache = {};
    return (...args) => {
      const key = JSON.stringify(args);
      if (cache[key]) return cache[key];
      cache[key] = fn(...args);
      return cache[key];
    };
  }
};
