/* ============================================================
   prefetch.js — Precarga inteligente de datos
============================================================ */

window.Prefetch = {
  cache: {},

  async fetch(url) {
    if (this.cache[url]) return this.cache[url];

    try {
      const res = await fetch(url);
      const data = await res.json();
      this.cache[url] = data;
      return data;
    } catch (err) {
      console.warn("Prefetch error:", err);
      return null;
    }
  },

  warmUp(urls = []) {
    urls.forEach(url => {
      this.fetch(url);
    });
  }
};
