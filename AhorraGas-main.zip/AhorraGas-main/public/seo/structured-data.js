(function() {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebApplication",
      "name": "AhorraGas",
      "alternateName": "Ahorra Gas Sevilla",
      "url": "https://ahorra-gas.vercel.app",
      "description": "Encuentra las gasolineras más baratas cerca de ti en Sevilla. Precios de gasolina 95, 98 y diésel actualizados cada hora desde datos oficiales del Ministerio de Industria.",
      "applicationCategory": "UtilitiesApplication",
      "operatingSystem": "Android, iOS, Web",
      "browserRequirements": "Requires JavaScript",
      "image": "https://ahorra-gas.vercel.app/img/logo.png",
      "screenshot": "https://ahorra-gas.vercel.app/img/logo.png",
      "featureList": [
        "Mapa interactivo de gasolineras",
        "Precios en tiempo real",
        "Comparador de precios",
        "Gasolineras favoritas",
        "Ordenar por distancia",
        "Filtrar por tipo de combustible"
      ],
      "offers": {
        "@type": "Offer",
        "price": "0",
        "priceCurrency": "EUR"
      },
      "creator": {
        "@type": "Person",
        "name": "Juan López Martos",
        "url": "https://www.linkedin.com/in/juan-l%C3%B3pez-martos-91382133a/"
      },
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "4.8",
        "ratingCount": "124"
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "AhorraGas",
      "url": "https://ahorra-gas.vercel.app",
      "logo": "https://ahorra-gas.vercel.app/img/logo.png",
      "contactPoint": {
        "@type": "ContactPoint",
        "email": "julomar2006@gmail.com",
        "contactType": "customer support",
        "availableLanguage": "Spanish"
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "¿Cómo encuentro la gasolinera más barata cerca de mí en Sevilla?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "AhorraGas muestra automáticamente las gasolineras más baratas de Sevilla ordenadas por precio. Activa el GPS para ordenarlas también por distancia."
          }
        },
        {
          "@type": "Question",
          "name": "¿Cada cuánto se actualizan los precios?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Los precios se actualizan cada hora directamente desde los datos oficiales del Ministerio de Industria de España."
          }
        },
        {
          "@type": "Question",
          "name": "¿Es gratuita la app AhorraGas?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Sí, AhorraGas es completamente gratuita y no requiere registro."
          }
        },
        {
          "@type": "Question",
          "name": "¿Qué tipos de combustible puedo comparar?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Puedes comparar precios de Gasolina 95, Gasolina 98 y Diésel en todas las gasolineras de Sevilla."
          }
        }
      ]
    }
  ];

  schemas.forEach(schema => {
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.text = JSON.stringify(schema);
    document.head.appendChild(script);
  });
})();