(function () {
  const metaData = {
    title: "AhorraGas — Gasolineras baratas en Sevilla | Precios en tiempo real",
    description: "Encuentra la gasolinera más barata cerca de ti en Sevilla. Precios de gasolina 95, 98 y diésel actualizados cada hora. Gratis y sin registro.",
    url: "https://ahorra-gas.vercel.app",
    image: "https://ahorra-gas.vercel.app/img/logo.png"
  };

  function setMeta(name, content) {
    let tag = document.querySelector(`meta[name="${name}"]`);
    if (!tag) {
      tag = document.createElement("meta");
      tag.setAttribute("name", name);
      document.head.appendChild(tag);
    }
    tag.setAttribute("content", content);
  }

  function setProperty(property, content) {
    let tag = document.querySelector(`meta[property="${property}"]`);
    if (!tag) {
      tag = document.createElement("meta");
      tag.setAttribute("property", property);
      document.head.appendChild(tag);
    }
    tag.setAttribute("content", content);
  }

  document.title = metaData.title;

  setMeta("description", metaData.description);
  setMeta("author", "Juan López Martos");
  setMeta("geo.region", "ES-AN");
  setMeta("geo.placename", "Sevilla");
  setMeta("geo.position", "37.3891;-5.9845");
  setMeta("ICBM", "37.3891, -5.9845");
  setMeta("robots", "index, follow");
  setMeta("theme-color", "#0f1117");
  setMeta("rating", "general");
  setMeta("revisit-after", "1 days");
  setMeta("language", "Spanish");

  setProperty("og:title", metaData.title);
  setProperty("og:description", metaData.description);
  setProperty("og:image", metaData.image);
  setProperty("og:url", metaData.url);
  setProperty("og:type", "website");
  setProperty("og:locale", "es_ES");
  setProperty("og:site_name", "AhorraGas");

  setMeta("twitter:card", "summary_large_image");
  setMeta("twitter:title", metaData.title);
  setMeta("twitter:description", metaData.description);
  setMeta("twitter:image", metaData.image);
  setMeta("twitter:site", "@ahorragas");
})();