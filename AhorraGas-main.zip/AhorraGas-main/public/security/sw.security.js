/* ============================================================
   sw-security.js — Seguridad adicional para el Service Worker
============================================================ */

/* Dominios permitidos explícitamente.
   Cualquier petición a un dominio fuera de esta lista
   que provenga del SW se bloquea.                        */
const ALLOWED_ORIGINS = new Set([
  "ahorra-gas.vercel.app",
  "sedeaplicaciones.minetur.gob.es",   // API oficial de carburantes
  "cartodb-basemaps-a.global.ssl.fastly.net",
  "cartodb-basemaps-b.global.ssl.fastly.net",
  "cartodb-basemaps-c.global.ssl.fastly.net",
  "cartodb-basemaps-d.global.ssl.fastly.net",
  "unpkg.com",                         // Leaflet, React (solo build dev)
  "fonts.googleapis.com",
  "fonts.gstatic.com",
]);

self.addEventListener("fetch", event => {
  const url = event.request.url;
  let origin;

  try {
    origin = new URL(url).hostname;
  } catch (_) {
    /* URL malformada — bloquear */
    event.respondWith(new Response("URL inválida", { status: 400 }));
    return;
  }

  /* ── Bloquea file:// (el SW nunca debería interceptarlos,
     pero por si acaso en entornos de desarrollo raros)    */
  if (url.startsWith("file://")) {
    event.respondWith(new Response("Protocolo no permitido", { status: 400 }));
    return;
  }

  /* ── Exige HTTPS en producción para todo excepto localhost */
  if (
    !url.startsWith("https://") &&
    origin !== "localhost" &&
    !origin.startsWith("127.")
  ) {
    event.respondWith(new Response("Solo se permite HTTPS", { status: 403 }));
    return;
  }

  /* ── Valida que el origen esté en la lista blanca ───────
     Solo aplica a peticiones de navegación y API,
     no a extensiones del propio navegador (chrome-extension://) */
  if (url.startsWith("https://") && !ALLOWED_ORIGINS.has(origin)) {
    console.warn("[SW] Petición bloqueada a origen no permitido:", origin);
    event.respondWith(
      new Response("Origen no autorizado", {
        status: 403,
        headers: { "Content-Type": "text/plain" }
      })
    );
    return;
  }

  /* ── Solo permite métodos seguros desde el SW ───────────
     La API del Ministerio es GET-only; rechaza POST/PUT/DELETE */
  if (
    url.includes("minetur.gob.es") &&
    event.request.method !== "GET"
  ) {
    event.respondWith(new Response("Método no permitido", { status: 405 }));
    return;
  }

  /* ── Todo OK: deja pasar la petición ────────────────────
     El service-worker.js principal se encarga del caché    */
});