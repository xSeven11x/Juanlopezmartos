/* ============================================================
   security-headers.js — Políticas de seguridad del lado cliente
============================================================ */

(function () {

  /* ── 1. Anti-clickjacking ──────────────────────────────────
     Si la app está dentro de un iframe ajeno, redirige al top.
     El try/catch es obligatorio: acceder a window.top.location
     lanza SecurityError si el iframe es cross-origin.          */
  try {
    if (window.top !== window.self) {
      window.top.location.replace(window.self.location.href);
    }
  } catch (_) {
    /* Iframe cross-origin: no podemos redirigir, pero sí
       ocultar el contenido para que el clickjacking no funcione */
    document.documentElement.style.display = "none";
  }

  /* ── 2. Referrer Policy ────────────────────────────────────
     Inyecta la meta tag si no existe ya en el HTML.
     (El atributo document.referrerPolicy no existe en todos
     los navegadores; la meta tag sí está bien soportada)       */
  if (!document.querySelector('meta[name="referrer"]')) {
    const meta = document.createElement("meta");
    meta.name    = "referrer";
    meta.content = "strict-origin-when-cross-origin";
    document.head.appendChild(meta);
  }

  /* ── 3. Detección de apertura en contexto inseguro ─────────
     Avisa en consola si la app se sirve por HTTP en producción.
     No bloquea nada (eso lo hace HSTS en el servidor), pero
     ayuda a detectar errores de configuración en Vercel.       */
  if (location.protocol === "http:" && location.hostname !== "localhost" &&
      !location.hostname.startsWith("127.") &&
      !location.hostname.startsWith("192.168.")) {
    console.warn(
      "⚠️ AhorraGas se está sirviendo por HTTP en producción. " +
      "Activa HTTPS y HSTS en Vercel para proteger a tus usuarios."
    );
  }

  /* ── 4. Bloquea navegación a URLs peligrosas ───────────────
     Intercepta clicks en <a href="javascript:..."> o
     <a href="data:..."> que podrían ejecutar código.           */
  document.addEventListener("click", function (e) {
    const a = e.target.closest("a[href]");
    if (!a) return;
    const href = a.getAttribute("href") || "";
    if (/^(javascript|data|vbscript):/i.test(href.trim())) {
      e.preventDefault();
      console.warn("🚫 Enlace bloqueado por seguridad:", href.slice(0, 80));
    }
  }, true); /* capture=true para interceptar antes que otros handlers */

})();