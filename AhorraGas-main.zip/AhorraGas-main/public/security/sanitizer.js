/* ============================================================
   sanitizer.js — Limpieza de entradas (anti-XSS)
============================================================ */

window.Sanitize = {

  /* Escapa caracteres peligrosos para insertar texto en HTML.
     Uso: cualquier dato externo que vaya dentro de innerHTML */
  text(input = "") {
    return String(input)
      .replace(/&/g,  "&amp;")   // ← AÑADIDO: debe ir primero para no doble-escapar
      .replace(/</g,  "&lt;")
      .replace(/>/g,  "&gt;")
      .replace(/"/g,  "&quot;")
      .replace(/'/g,  "&#39;")
      .replace(/`/g,  "&#96;")   // ← AÑADIDO: evita inyección en template literals
      .replace(/\//g, "&#x2F;"); // ← AÑADIDO: cierra etiquetas tipo </script>
  },

  /* Escapa una URL antes de ponerla en href= o src=.
     Bloquea javascript: y data: que bypassan el escape de texto */
  url(input = "") {
    const s = String(input).trim();
    if (/^(javascript|data|vbscript):/i.test(s)) return "#";
    return s;
  },

  /* Escapa para usar dentro de un atributo HTML ya entre comillas:
     <div data-x="...Sanitize.attr(val)..."> */
  attr(input = "") {
    return this.text(input);
  },

  /* Alias corto para usar en buildPopupHtml y similares */
  e(input = "") {
    return this.text(input);
  }
};