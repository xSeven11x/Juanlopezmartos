/* ============================================================
   rate-limit.js — Límite de peticiones por usuario
============================================================ */

const RateLimit = {
  maxRequests: 5,       // máximo de llamadas a la API del Ministerio
  interval: 30000,      // en una ventana de 30 segundos
  requests: [],

  /* Dominio exacto al que aplicar el límite.
     No interceptamos Leaflet tiles, fuentes, ni otros recursos. */
  TARGET: "sedeaplicaciones.minetur.gob.es",

  check() {
    const now = Date.now();
    // Limpia peticiones fuera de la ventana
    this.requests = this.requests.filter(t => now - t < this.interval);

    if (this.requests.length >= this.maxRequests) {
      console.warn("⚠️ Rate limit: demasiadas peticiones a la API del Ministerio");
      return false;
    }

    this.requests.push(now);
    return true;
  },

  /* Tiempo en ms hasta que se libera un hueco */
  retryAfter() {
    if (!this.requests.length) return 0;
    const oldest = this.requests[0];
    return Math.max(0, this.interval - (Date.now() - oldest));
  }
};

/* Intercepta solo las peticiones dirigidas al Ministerio */
const _originalFetch = window.fetch;
window.fetch = function (...args) {
  const url = typeof args[0] === "string"
    ? args[0]
    : args[0] instanceof Request ? args[0].url : "";

  if (url.includes(RateLimit.TARGET)) {
    if (!RateLimit.check()) {
      const wait = Math.ceil(RateLimit.retryAfter() / 1000);
      const err = new Error(`Rate limit: espera ${wait}s antes de volver a consultar`);
      err.name  = "RateLimitError";
      return Promise.reject(err);
    }
  }

  return _originalFetch(...args);
};