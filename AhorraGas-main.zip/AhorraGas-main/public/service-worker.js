const CACHE_NAME = "ahorragas-v6.3.10";

const STATIC_ASSETS = [
  "/",
  "/index.html",
  "/style.css",
  "/app.js",
  "/img/logo.png"
];

const SENSITIVE_URLS = ["/admin", "/config", "/private"];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(STATIC_ASSETS).catch(err => {
        console.warn("Error cacheando assets:", err);
      });
    })
  );
  self.skipWaiting();
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", event => {
  const url = event.request.url;

  // ⛔ IGNORAR peticiones que NO sean http/https (evita error chrome-extension)
  if (!url.startsWith("http")) {
    return;
  }

  // ⛔ Rutas sensibles → nunca cachear
  if (SENSITIVE_URLS.some(s => url.includes(s))) {
    return event.respondWith(fetch(event.request));
  }

  // ⛔ Librerías externas → no cachear
  if (
    url.includes("unpkg.com") ||
    url.includes("fonts.googleapis.com") ||
    url.includes("fonts.gstatic.com")
  ) {
    return event.respondWith(fetch(event.request));
  }

  // 📌 Archivos propios críticos → Network First
  const ownFiles = ["/index.html", "/app.js", "/style.css", "/service-worker.js"];
  const isOwnFile =
    ownFiles.some(f => url.endsWith(f)) ||
    url === self.location.origin + "/";

  if (isOwnFile) {
    return event.respondWith(
      fetch(event.request)
        .then(response => {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
          return response;
        })
        .catch(() => caches.match(event.request))
    );
  }

  // ⛽ API del Ministerio → Network First
  if (url.includes("sedeaplicaciones.minetur.gob.es")) {
    return event.respondWith(
      fetch(event.request)
        .then(response => {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
          return response;
        })
        .catch(() => caches.match(event.request))
    );
  }

  // 📦 Todo lo demás → Cache First
  event.respondWith(
    caches.match(event.request).then(cached => {
      return (
        cached ||
        fetch(event.request).then(response => {
          if (response && response.status === 200) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
          }
          return response;
        })
      );
    })
  );
});
