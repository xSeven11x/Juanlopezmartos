window.Analytics = {
  log(event, data = {}) {
    if (typeof window === "undefined") return;
    const payload = {
      event,
      data,
      timestamp: new Date().toISOString(),
      url: window.location.href
    };
    console.log("📊 Analytics:", payload);
  },

  pageView() {
    this.log("page_view");
  },

  gasolineraClick(id) {
    this.log("gasolinera_click", { id });
  },

  favoritoToggle(id, estado) {
    this.log("favorito_toggle", { id, estado });
  },

  busqueda(query) {
    this.log("busqueda", { query });
  },

  cambioFuel(fuel) {
    this.log("cambio_fuel", { fuel });
  }
};

document.addEventListener("DOMContentLoaded", () => {
  window.Analytics.pageView();
});