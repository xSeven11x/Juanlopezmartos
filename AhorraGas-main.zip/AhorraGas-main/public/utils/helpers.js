window.Helpers = {
  toFixed(num, decimals = 2) {
    return Number(num).toFixed(decimals);
  },

  formatPrice(value) {
    return `${Number(value).toFixed(3)} €/L`;
  },

  // Distancia Haversine — misma lógica que distanceKm() en app.js
  distance(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos(lat1 * Math.PI / 180) *
      Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) ** 2;
    return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
  },

  capitalize(text = "") {
    return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
  },

  uid() {
    return "_" + Math.random().toString(36).substring(2, 11);
  },

  // Formatea milisegundos a texto legible
  timeAgo(ms) {
    const mins = Math.floor(ms / 60000);
    if (mins < 1) return "ahora mismo";
    if (mins < 60) return `hace ${mins} min`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `hace ${hrs}h`;
    return `hace ${Math.floor(hrs / 24)} días`;
  }
};