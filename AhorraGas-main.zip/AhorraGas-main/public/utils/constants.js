window.Constants = {
  API_BASE:
    "https://sedeaplicaciones.minetur.gob.es/ServiciosRESTCarburantes/PreciosCarburantes",

  ENDPOINTS: {
    PROVINCIA: "/EstacionesTerrestres/FiltroProvincia/",
    TODAS: "/EstacionesTerrestres/"
  },

  DEFAULT_PROVINCIA: "41", // Sevilla

  RATE_LIMIT: {
    MAX_REQUESTS: 5,
    INTERVAL: 30000  // sincronizado con rate-limit.js
  },

  CACHE: {
    GASOLINERAS: "ahorragas_data",  // sincronizado con app.js
    TTL: 60 * 60 * 1000            // sincronizado con app.js (1 hora)
  },

  MAP: {
    DEFAULT_ZOOM: 11,  // sincronizado con app.js
    DEFAULT_LAT: 37.3891,
    DEFAULT_LON: -5.9845
  }
};